public class Main {
    public static void main(String[] args) {
        // Membuat aplikasi biodata
        String nama;
        String nim;
        String prodi;
        String tgl_lahir;
        float tinggi_badan;
        double berat_badan;
        boolean status; // jika menikah = TRUE, belum menikah = FALSE

        // Deklarasi variabel dan tipe data
        nama = "Muhammad Azhari Zulfiansyah";
        nim = "23241098";
        prodi = "Pendidikan Teknologi Informasi";
        tgl_lahir = "25 Mei 2005";
        tinggi_badan = 163.5f;
        berat_badan = 57.6d;
        status = false;
        // Mencetak biodata ke layar komputer
        System.out.println("============================================");
        System.out.println("Nama Mahasiswa : " + nama);
        System.out.println("NIM : " + nim);
        System.out.println("Prodi : " + prodi);
        System.out.println("Tanggal Lahir : " + tgl_lahir);
        System.out.println("Tinggi Badan : " + tinggi_badan );
        System.out.println("Berat Badan : " + berat_badan);
        System.out.println("status : " + status);
        System.out.println("============================================");

    }
}
