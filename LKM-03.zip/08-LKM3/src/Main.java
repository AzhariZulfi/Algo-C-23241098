import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int diskon = 0;

        // Input apakah pengguna memiliki kartu
        System.out.print("Apakah anda memiliki kartu? (iya/tidak): ");
        String jawaban = input.nextLine();

        // Input jumlah belanja dari pengguna
        System.out.print("Masukkan uang: ");
        int belanja = input.nextInt();

        // Proses diskon jika pengguna memiliki kartu
        if (jawaban.equalsIgnoreCase("iya")) {
            if (belanja > 500000) {
                // Potongan 50rb untuk belanja di atas 500rb
                diskon = belanja - 50000;
                System.out.println("============================================");
                System.out.println("Selamat anda mendapat potongan 50rb");
                System.out.println("Total pembayaran: Rp." + diskon);
            } else if (belanja > 100000) {
                // Potongan 15rb untuk belanja di atas 100rb
                diskon = belanja - 15000;
                System.out.println("============================================");
                System.out.println("Selamat anda mendapat potongan 15rb");
                System.out.println("Total pembayaran: Rp." + diskon);
            } else {
                // Tidak ada potongan jika belanja di bawah 100rb
                System.out.println("============================================");
                System.out.println("Tidak ada potongan, total pembayaran: Rp." + belanja);
            }
            
        } else if (jawaban.equalsIgnoreCase("tidak")) {
            // Proses diskon jika pengguna tidak memiliki kartu
            if (belanja > 100000) {
                // Potongan 5rb untuk belanja di atas 100rb
                diskon = belanja - 5000;
                System.out.println("==============================================");
                System.out.println("Selamat anda mendapat potongan 5rb");
                System.out.println("Total pembayaran: Rp." + diskon);
            } else {
                // Tidak ada potongan jika belanja di bawah 100rb
                System.out.println("==============================================");
                System.out.println("Tidak ada potongan, total pembayaran: Rp." + belanja);
            }
        }

        // Menutup Scanner
        input.close();
    }
}