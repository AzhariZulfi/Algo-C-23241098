import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
       // Data Member
       int total_belanja = 0;

       //Membuat objek scanner baru
       Scanner input = new Scanner(System.in);

       //Mengambil Input
       System.out.println("Masukkan total belanja : ");
       total_belanja = input.nextInt();

       //Memeriksa apakah jumlah belanja lebih dari 50000
       if (total_belanja >= 50000){
        System.out.println("Selamat! Anda mendapatkan mouse");

       }else{
        System.out.println("Maaf anda tidak mendapatkan mouse");
       }

       System.out.println("Terima Kasih");

       //Menutup objek scanner
       input.close();

    }
}
