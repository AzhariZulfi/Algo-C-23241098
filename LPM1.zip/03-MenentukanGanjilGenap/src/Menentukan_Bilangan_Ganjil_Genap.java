import java.util.Scanner;
public class Menentukan_Bilangan_Ganjil_Genap {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       
       System.out.println("Masukkan sebuah bilangan");
       System.out.println("------------------------");

       int bilangan = input.nextInt();
            if (bilangan  % 2 == 0){
                System.out.println(bilangan + " " + "adalah bilangan genap.");
            }else{
                System.out.println(bilangan + " " +"adalah bilangan ganjil.");
            }
            input.close();
            }
    }
