import java.util.Scanner;

public class HitungVolumeBola {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Program Menghitung Volume Bola");
        System.out.println("-----------------------------");

        System.out.print("Masukkan jari-jari bola: ");
        double JariJari = input.nextDouble();

        // Menghitung volume bola menggunakan rumus V = (4/3) * π * r^3
        double volume = (4.0 / 3.0) * Math.PI * Math.pow(JariJari, 3);

        System.out.println("Volume bola dengan jari-jari " + JariJari + " adalah: " + volume);

        input.close();
    }
}