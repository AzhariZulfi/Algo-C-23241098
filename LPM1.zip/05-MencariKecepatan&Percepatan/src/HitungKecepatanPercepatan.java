import java.util.Scanner;

public class HitungKecepatanPercepatan {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Program Menghitung Kecepatan dan Percepatan");
        System.out.println("------------------------------------------");

        System.out.print("Masukkan nilai awal kecepatan (v0): ");
        double v0 = input.nextDouble();

        System.out.print("Masukkan nilai akhir kecepatan (v): ");
        double v = input.nextDouble();

        System.out.print("Masukkan waktu yang diperlukan (t): ");
        double t = input.nextDouble();

        double Vavg = (v + v0) / 2;

        double a = (v - v0) / t;

        System.out.println("Kecepatan rata-rata: " + Vavg);
        System.out.println("Percepatan: " + a);

        input.close();
    }
}