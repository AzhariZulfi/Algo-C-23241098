import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Program Cek Tahun Kabisat");
        System.out.println("===========================");
        System.out.print("Masukkan jumlah tahun: ");
        int jumlahTahun = scanner.nextInt();

        for (int i = 1; i <= jumlahTahun; i++) {
            System.out.print("Masukkan tahun ke-" + i + ": ");
            int tahun = scanner.nextInt();

            if ((tahun % 4 == 0) && ((tahun % 100 != 0) || (tahun % 400 == 0))) {
                System.out.println(tahun + " adalah tahun kabisat.");
            } else {
                System.out.println(tahun + " bukan tahun kabisat.");
            }
        }

        scanner.close();
    }
}